package com.project.didi;

public interface ChangeNumberItemsListener {
    void changed();
}
